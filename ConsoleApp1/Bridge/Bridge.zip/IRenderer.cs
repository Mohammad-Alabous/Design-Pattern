﻿namespace ME.DesignPattern.Main.Bridge
{
    public interface IRenderer
    {
        void Render(string shapeType);
    }
}
