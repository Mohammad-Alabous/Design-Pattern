﻿namespace ME.DesignPattern.Main.Composite
{
    public interface IMenuComponent
    {
        void Display(int indent = 0);
    }
}
