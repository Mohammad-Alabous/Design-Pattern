﻿namespace ME.DesignPattern.Main.Adapter
{
    public interface ILogger
    {
        void Log(string message);
    }
}
